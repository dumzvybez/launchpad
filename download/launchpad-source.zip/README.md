# Launchpad — Coding Education Platform

A free, privacy-first coding education platform with a personalized learning engine, 30+ built-in lessons, an in-browser code playground, daily challenges, and an AI tutor — all running entirely on-device.

![Launchpad](public/icons/logo-1024.png)

## ✨ Features

### 🧠 Personalization Engine
Launchpad builds a unique 6-phase roadmap for every user based on:
- **Career choice** — 8 careers supported (Software Engineering with 5 sub-paths, Web Dev, Cloud/DevOps, Data Science, AI/ML, Cybersecurity, Mobile Dev, Game Dev, Hardware/Embedded)
- **Languages & frameworks** — 24+ entries with rich metadata (demand, salary impact, use cases, difficulty, trend, top companies)
- **Current occupation** — adjusts pace (foundational depth for students, condensed for professionals)
- **Skill level** — beginner, intermediate, or advanced starting point
- **Weekly availability** — fine-tunes timeline

The engine runs a **secondary automated accuracy check** on every generated roadmap (validating phases, content, dependencies, language coverage, timeline, and numbering), then optionally refines it with AI and re-validates.

### 🪄 7-Step Onboarding
1. **Privacy intro** — what Launchpad does, why it exists, on-device storage explanation
2. **Name + goal** — pick your target career
3. **Occupation + career detail** — see salary, demand, languages, top companies
4. **Language selection** — auto-recommended based on career; rich popover panels for each language
5. **Skill level** — beginner / intermediate / advanced
6. **Availability** — hours/day × days/week with live timeline estimate
7. **Plan preview** — 7-stage animated generation with accuracy validation

### 🗺️ Roadmap
- 6 phase boxes in a grid
- Click a phase → it maximises → shows modules as connected arrows
- Click a module → maximises → shows task list
- Click a task → full details with code examples and "Try in Playground" buttons
- Breadcrumb navigation at every level
- Locked phases still viewable but tasks can't be marked complete

### 📚 Learn
- **30 built-in lessons**: 15 Python + 15 JavaScript
- Each lesson: explanation, code examples, tips, warnings, external resources
- Multiple-choice quiz after each lesson
- Progress tracking (not started / in progress / complete)
- **PDF certificate** generation when you complete all lessons in a track

### 🤖 AI Tutor
- Floating chat bubble (bottom-right corner, visible on all pages)
- Click opens a 380px floating window; Maximize button opens as full tab
- Conversation-based history with auto-generated titles
- **Markdown rendering**: bold, italic, inline code, code blocks with copy buttons
- **Rate limiting**: 15 messages per 2-hour window (on-device tracking)
- **Bring your own API key**: Z.ai (default), OpenAI, Groq, or custom endpoint
- Settings: provider, model, temperature, clear history, privacy notice
- First-time privacy warning + "AI may make mistakes" disclaimer

### 🧩 Code Playground
- Only visible if JavaScript or TypeScript is in your plan
- Runs JavaScript in-browser with console output capture
- Code examples, copy/clear buttons
- "Try in Playground" buttons on roadmap code samples pre-load the code

### 📅 Daily Challenge
- 7 rotating coding challenges (one per day of the week)
- Streak tracking, hints, reference solutions
- Run code directly or open in Playground

### 🌳 Skill Tree
- Vertical connected path with a gradient flowing line between phase nodes
- Module dots shown as smaller nodes branching off the main path
- Click any phase to jump to the roadmap

### 🏅 Achievements
- **24+ achievement badges** across 4 rarity tiers (common / rare / epic / legendary)
- Examples: First Lesson, Quiz Master, Week Warrior, Centurion (100-day streak), Code Legend, Polyglot, Night Owl, Early Bird, Project Shipper
- Animated toast popup when a badge is earned

### 🎨 UI/UX
- Modern glassmorphism design with aurora gradient background
- **10 background themes** (Aurora, Ocean, Forest, Sunset, Midnight, Lavender, Rose, Mint, Slate, Custom) + custom color picker
- Dark/light theme toggle
- Density toggle (comfortable / compact)
- Reduce motion option
- Splash screen with cycling subtitles (toggleable)
- All modals fit within viewport (`max-h-[85vh] overflow-y-auto`)

### 🔒 Privacy & Data
- **100% on-device storage** (localStorage) — no servers, no accounts, no sync
- Daily auto-backup to localStorage + manual download/restore
- Privacy notices clearly state: on-device storage, AI tutor sends messages to servers, no data sold or used for ads

### 📱 Mobile / Tablet
- Hamburger menu (top-right) opens slide-out drawer on mobile/tablet
- Profile icon dropdown with Account and Settings
- "Use desktop for better experience" banner (dismissible per session)
- Stacked layouts, larger touch targets

### 🧭 First-Time Tour
After onboarding, an overlay walkthrough highlights each tab with sequential tooltips, "Skip" button, and "Don't show again" checkbox.

### 🆘 Help Centre
12+ Q&A entries in an accordion inside Settings.

## 🛠️ Tech Stack

- **Framework**: Next.js 16 with App Router
- **Language**: TypeScript 5
- **Styling**: Tailwind CSS 4 with shadcn/ui
- **State**: Zustand (client state) + TanStack Query (server state)
- **Database**: Prisma ORM with SQLite
- **AI**: z-ai-web-dev-sdk (Z.ai GLM-4.6 default), supports OpenAI/Groq/custom
- **PWA**: Installable, offline-capable, custom splash screen

## 🚀 Getting Started

### Prerequisites
- Node.js 18+ or Bun
- npm/bun package manager

### Installation
```bash
# Clone the repo
git clone https://github.com/yourname/launchpad.git
cd launchpad

# Install dependencies
bun install  # or npm install

# Run the dev server
bun run dev  # or npm run dev

# Open http://localhost:3000
```

### Build for production
```bash
bun run build
bun run start
```

## 📦 Deployment

Launchpad is a static-friendly Next.js app — deploy on:
- **Vercel** (recommended): `vercel deploy`
- **Netlify**: `netlify deploy --build`
- **Cloudflare Pages**: connect repo, set framework to Next.js
- **Self-host**: `bun run build && bun run start`

No environment variables required for default usage. To use a different AI provider, users add their own API key in-app (stored on-device).

## 🔐 Privacy

| Data | Stored where | Sent to server? |
|------|-------------|----------------|
| Profile, progress, roadmap, badges | localStorage | No |
| Lesson progress, quiz scores | localStorage | No |
| AI chat history | localStorage | No (only the messages you send) |
| AI tutor messages | — | Yes — sent to AI servers (Z.ai by default, or your provider) for processing |
| Settings, preferences | localStorage | No |

We don't have accounts. We don't sync across devices. We don't sell data or use it for ads. Clearing your browser erases everything — use Settings → Backup to export a copy.

## 🤝 Contributing

Contributions welcome! Please:
1. Fork the repo
2. Create a feature branch
3. Run `bun run lint` — must be clean
4. Open a pull request

## 📄 License

MIT — free for personal and commercial use.

## 🙏 Acknowledgements

Built with the [Z.ai](https://z.ai) GLM-4.6 model as the default AI tutor. Powered by Next.js, Tailwind CSS, shadcn/ui, and the open-source community.
